import React from 'react';
import '../app.css';
import Calculadora from './calculadora';

function App() {
  return (
    <div className="App">
      <Calculadora />
    </div>
  );
}

export default App;
