import axios from 'axios';
import React, { useState } from 'react';
import './Calculadora.css'; 

const Calculadora = () => {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [resultado, setResultado] = useState('');
  const [historial, setHistorial] = useState([]);

  const manejarCambio = (e, setter) => {
    setter(e.target.value);
  };

  const realizarOperacion = async (operacion) => {
    try {
      const response = await axios.get(`http://localhost:8080/api/calculadora/${operacion}`, {
        params: { num1, num2 }
      });
      setResultado(response.data);
      obtenerHistorial();
    } catch (error) {
      setResultado(error.response ? error.response.data : 'Error en la operación');
    }
  };

  const obtenerHistorial = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/calculadora/historial');
      setHistorial(response.data);
    } catch (error) {
      console.error('Error obteniendo el historial:', error);
    }
  };

  return (
    <div className="calculadora-container">
      <h1>Calculadora</h1>
      <div>
        <input
          type="number"
          value={num1}
          onChange={(e) => manejarCambio(e, setNum1)}
          placeholder="Número 1"
        />
        <input
          type="number"
          value={num2}
          onChange={(e) => manejarCambio(e, setNum2)}
          placeholder="Número 2"
        />
      </div>
      <div>
        <button onClick={() => realizarOperacion('sumar')}>Sumar</button>
        <button onClick={() => realizarOperacion('restar')}>Restar</button>
        <button onClick={() => realizarOperacion('multiplicar')}>Multiplicar</button>
        <button onClick={() => realizarOperacion('dividir')}>Dividir</button>
      </div>
      <div className="resultado">
        <h2>Resultado: {resultado}</h2>
      </div>
      <div className="historial">
        <h2>Historial de Operaciones:</h2>
        <ul>
          {historial.map((item, index) => (
            <li key={index}>
              {item.tipo}: {item.num1} {getOperacionSimbolo(item.tipo)} {item.num2} = {item.resultado}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

// Función auxiliar para obtener el símbolo de la operación
const getOperacionSimbolo = (tipo) => {
  switch (tipo) {
    case 'Suma': return '+';
    case 'Resta': return '-';
    case 'Multiplicación': return '*';
    case 'División': return '/';
    default: return '';
  }
};

export default Calculadora;