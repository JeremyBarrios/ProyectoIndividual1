package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/calculadora")
@CrossOrigin(origins = "http://localhost:3000")
public class ControlCalculadora {

    // Modelo de operación dentro del mismo archivo del controlador
    public static class Operacion {
        private String tipo;
        private double num1;
        private double num2;
        private double resultado;

        public Operacion(String tipo, double num1, double num2, double resultado) {
            this.tipo = tipo;
            this.num1 = num1;
            this.num2 = num2;
            this.resultado = resultado;
        }

        // Getters y Setters
        public String getTipo() { return tipo; }
        public void setTipo(String tipo) { this.tipo = tipo; }
        public double getNum1() { return num1; }
        public void setNum1(double num1) { this.num1 = num1; }
        public double getNum2() { return num2; }
        public void setNum2(double num2) { this.num2 = num2; }
        public double getResultado() { return resultado; }
        public void setResultado(double resultado) { this.resultado = resultado; }
    }

    private static final List<Operacion> historial = new ArrayList<>();

    // Método para agregar operación al historial
    private void registrarOperacion(String tipo, double num1, double num2, double resultado) {
        Operacion operacion = new Operacion(tipo, num1, num2, resultado);
        if (historial.size() >= 10) {
            historial.remove(0);  // Mantener solo las últimas 10 operaciones
        }
        historial.add(operacion);
    }

    @GetMapping("/sumar")
    public double sumar(@RequestParam double num1, @RequestParam double num2) {
        double resultado = calcularResultado("Suma", num1, num2);
        return resultado;
    }

    @GetMapping("/restar")
    public double restar(@RequestParam double num1, @RequestParam double num2) {
        double resultado = calcularResultado("Resta", num1, num2);
        return resultado;
    }

    @GetMapping("/multiplicar")
    public double multiplicar(@RequestParam double num1, @RequestParam double num2) {
        double resultado = calcularResultado("Multiplicación", num1, num2);
        return resultado;
    }

    @GetMapping("/dividir")
    public double dividir(@RequestParam double num1, @RequestParam double num2) {
        if (num2 == 0) {
            throw new ArithmeticException("No se puede dividir por cero");
        }
        double resultado = calcularResultado("División", num1, num2);
        return resultado;
    }

    // Nuevo método que unifica la lógica de cálculo para cualquier operación
    private double calcularResultado(String tipo, double num1, double num2) {
        double resultado = 0;
        switch (tipo) {
            case "Suma":
                resultado = num1 + num2;
                break;
            case "Resta":
                resultado = num1 - num2;
                break;
            case "Multiplicación":
                resultado = num1 * num2;
                break;
            case "División":
                resultado = num1 / num2;
                break;
        }
        registrarOperacion(tipo, num1, num2, resultado);
        return resultado;
    }

    @GetMapping("/historial")
    public List<Operacion> getHistorial() {
        return historial;
    }
}
